1.	Ensure MySQL server is installed and running
2.	Double click the set up to install the application.
3.	Navigate through the tables in the panel to fill the data in the form
4.	if stuck, contact me through http://mckabue.wordpress.com/contact/
5.	you require MySQL Workbench client to view the Entity Model
6.	PAYMENT IS 3,500/=